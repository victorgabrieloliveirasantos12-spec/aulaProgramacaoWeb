export class Templates {
    static home() {
        return `
            <div class="home-page">
                <section class="hero">
                    <div class="container">
                        <div class="hero-content">
                            <h1>Bem-vindo ao meu <span class="highlight">Portfólio</span></h1>
                            <p class="subtitle">Desenvolvedor Web Full Stack</p>
                            <div class="hero-buttons">
                                <a href="#projetos" class="btn btn-primary">Ver Projetos</a>
                                <a href="#cadastro" class="btn btn-outline">Criar Conta</a>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="features">
                    <div class="container">
                        <h2>Tecnologias</h2>
                        <div class="features-grid">
                            <div class="feature-card">
                                <h3>Frontend</h3>
                                <p>HTML5, CSS3, JavaScript</p>
                            </div>
                            <div class="feature-card">
                                <h3>Backend</h3>
                                <p>Node.js, Python, APIs</p>
                            </div>
                            <div class="feature-card">
                                <h3>Databases</h3>
                                <p>MongoDB, MySQL</p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        `;
    }

    static projects() {
        return `
            <div class="projects-page">
                <div class="container">
                    <h1>Meus Projetos</h1>
                    <div class="projects-grid">
                        <div class="project-card">
                            <h3>Projeto 1</h3>
                            <p>Descrição do projeto</p>
                            <div class="project-links">
                                <a href="#" class="btn btn-primary">Ver Mais</a>
                            </div>
                        </div>
                        <div class="project-card">
                            <h3>Projeto 2</h3>
                            <p>Descrição do projeto</p>
                            <div class="project-links">
                                <a href="#" class="btn btn-primary">Ver Mais</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    static register() {
        return `
            <div class="register-page">
                <div class="container">
                    <div class="form-container">
                        <h1>Criar Conta</h1>
                        <form id="registerForm" class="form">
                            <div class="form-group">
                                <label for="name" class="form-label">Nome</label>
                                <input type="text" id="name" name="name" class="form-input" required>
                            </div>
                            <div class="form-group">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" id="email" name="email" class="form-input" required>
                            </div>
                            <div class="form-group">
                                <label for="password" class="form-label">Senha</label>
                                <input type="password" id="password" name="password" class="form-input" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Cadastrar</button>
                            <p class="form-footer">
                                Já tem uma conta? <a href="#login">Fazer login</a>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        `;
    }

    static login() {
        return `
            <div class="login-page">
                <div class="container">
                    <div class="form-container">
                        <h1>Login</h1>
                        <form id="loginForm" class="form">
                            <div class="form-group">
                                <label for="loginEmail" class="form-label">Email</label>
                                <input type="email" id="loginEmail" name="email" class="form-input" required>
                            </div>
                            <div class="form-group">
                                <label for="loginPassword" class="form-label">Senha</label>
                                <input type="password" id="loginPassword" name="password" class="form-input" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Entrar</button>
                            <p class="form-footer">
                                Não tem uma conta? <a href="#cadastro">Criar conta</a>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        `;
                                <img src="images/profile.jpg" alt="Minha foto" class="profile-image">
                                <div class="experience-card">
                                    <span class="number">4+</span>
                                    <span class="text">Anos de<br>Experiência</span>
                                </div>
                            </div>
                            <div class="about-content">
                                <h2>Sobre Mim</h2>
                                <p class="lead">Desenvolvedor web apaixonado por transformar ideias em realidade através de código limpo e design intuitivo.</p>
                                <div class="skills-grid">
                                    <div class="skill-card">
                                        <svg class="skill-icon" viewBox="0 0 24 24">
                                            <path d="M12 21l-8-9h16l-8 9z"/>
                                        </svg>
                                        <h3>Front-end</h3>
                                        <p>Criação de interfaces responsivas e acessíveis</p>
                                    </div>
                                    <div class="skill-card">
                                        <svg class="skill-icon" viewBox="0 0 24 24">
                                            <path d="M4 6h16M4 12h16M4 18h16"/>
                                        </svg>
                                        <h3>Back-end</h3>
                                        <p>Desenvolvimento de APIs e sistemas robustos</p>
                                    </div>
                                    <div class="skill-card">
                                        <svg class="skill-icon" viewBox="0 0 24 24">
                                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                                        </svg>
                                        <h3>UI/UX</h3>
                                        <p>Design de experiências intuitivas e agradáveis</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Projetos em Destaque -->
                <section class="featured-projects animate-on-scroll" id="featured-projects">
                    <div class="container">
                        <header class="section-header">
                            <h2>Projetos em Destaque</h2>
                            <p>Confira alguns dos meus trabalhos mais recentes</p>
                        </header>
                        <div class="projects-grid">
                            ${Projects.getFeaturedProjects()}
                        </div>
                        <div class="section-footer">
                            <a href="#projetos" class="btn btn-secondary">
                                Ver Todos os Projetos
                                <svg class="icon" viewBox="0 0 24 24">
                                    <path d="M5 12h14M12 5l7 7-7 7"/>
                                </svg>
                            </a>
                        </div>
                    </div>
                </section>

                <!-- CTA Section -->
                <section class="cta-section animate-on-scroll">
                    <div class="container">
                        <div class="cta-content">
                            <h2>Vamos Trabalhar Juntos?</h2>
                            <p>Estou sempre em busca de novos projetos e desafios interessantes</p>
                            <a href="#contato" class="btn btn-primary btn-large">Entre em Contato</a>
                        </div>
                        <ul class="stats-list">
                            <li class="stat-item">
                                <span class="stat-number">50+</span>
                                <span class="stat-label">Projetos<br>Concluídos</span>
                            </li>
                            <li class="stat-item">
                                <span class="stat-number">30+</span>
                                <span class="stat-label">Clientes<br>Satisfeitos</span>
                            </li>
                            <li class="stat-item">
                                <span class="stat-number">4+</span>
                                <span class="stat-label">Anos de<br>Experiência</span>
                            </li>
                        </ul>
                    </div>
                </section>
            </div>
        `;
    }

    static projects() {
        return `
            <section class="projects-page">
                <div class="container">
                    <h1>Meus Projetos</h1>
                    <div class="filter-container">
                        <form id="filter-form" class="filter-form">
                            <div class="filter-group">
                                <label for="category">Categoria</label>
                                <select id="category" name="category">
                                    <option value="">Todas</option>
                                    <option value="web">Web</option>
                                    <option value="mobile">Mobile</option>
                                    <option value="desktop">Desktop</option>
                                </select>
                            </div>
                            <div class="filter-group">
                                <label for="tech">Tecnologia</label>
                                <select id="tech" name="tech">
                                    <option value="">Todas</option>
                                    <option value="javascript">JavaScript</option>
                                    <option value="python">Python</option>
                                    <option value="java">Java</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Filtrar</button>
                        </form>
                    </div>
                    <div class="projects-grid">
                        ${Projects.getAllProjects()}
                    </div>
                    <div class="pagination"></div>
                </div>
            </section>
        `;
    }

    static register() {
        return `
            <section class="register-page">
                <div class="container">
                    <div class="form-container">
                        <h1>Criar Conta</h1>
                        <form id="registerForm" class="register-form">
                            <div class="form-field">
                                <label for="name">Nome Completo</label>
                                <input type="text" id="name" name="name" required>
                            </div>
                            
                            <div class="form-field">
                                <label for="email">E-mail</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            
                            <div class="form-field">
                                <label for="password">Senha</label>
                                <input type="password" id="password" name="password" required>
                            </div>
                            
                            <div class="form-field">
                                <label for="confirmPassword">Confirmar Senha</label>
                                <input type="password" id="confirmPassword" name="confirmPassword" required>
                            </div>
                            
                            <div class="terms-group">
                                <label class="checkbox-item">
                                    <input type="checkbox" name="terms" required>
                                    <span>Li e aceito os Termos de Uso</span>
                                </label>
                            </div>
                            
                            <button type="submit" class="submit-button">
                                <span>Criar minha conta</span>
                            </button>
                        </form>
                        <div class="form-footer">
                            <p>Já tem uma conta? <a href="#login">Fazer login</a></p>
                        </div>
                    </div>
                </div>
            </section>
        `;
    }

    static login() {
        return `
            <section class="login-page">
                <div class="container">
                    <div class="form-container">
                        <h1>Login</h1>
                        <form id="loginForm" class="login-form">
                            <div class="form-field">
                                <label for="loginEmail">E-mail</label>
                                <input type="email" id="loginEmail" name="email" required>
                            </div>
                            
                            <div class="form-field">
                                <label for="loginPassword">Senha</label>
                                <input type="password" id="loginPassword" name="password" required>
                            </div>
                            
                            <button type="submit" class="submit-button">
                                <span>Entrar</span>
                            </button>
                        </form>
                        <div class="form-footer">
                            <p>Ainda não tem uma conta? <a href="#cadastro">Cadastre-se</a></p>
                            <p><a href="#recuperar-senha">Esqueceu sua senha?</a></p>
                        </div>
                    </div>
                </div>
            </section>
        `;
    }

    static notFound() {
        return `
            <section class="not-found-page">
                <div class="container">
                    <h1>Página não encontrada</h1>
                    <p>A página que você está procurando não existe ou foi movida.</p>
                    <a href="#" class="btn btn-primary">Voltar para o início</a>
                </div>
            </section>
        `;
    }

    static error() {
        return `
            <section class="error-page">
                <div class="container">
                    <h1>Ops! Algo deu errado</h1>
                    <p>Ocorreu um erro ao carregar a página. Por favor, tente novamente mais tarde.</p>
                    <a href="#" class="btn btn-primary">Voltar para o início</a>
                </div>
            </section>
        `;
    }
}